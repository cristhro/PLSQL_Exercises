select
color from cust
where id=500;