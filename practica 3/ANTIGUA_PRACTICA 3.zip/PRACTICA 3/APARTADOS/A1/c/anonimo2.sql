commit;
set transaction isolation level serializable;

begin
probarmitrans2();
end;