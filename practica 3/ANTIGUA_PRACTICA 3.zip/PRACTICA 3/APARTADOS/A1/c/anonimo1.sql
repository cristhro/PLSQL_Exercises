commit;
set transaction isolation level serializable;

begin
probarmitrans1();
end;