SELECT  ABD0404A.sec_trans_1.NEXTVAL 
FROM dual;
    
SELECT  sec_trans_2.NEXTVAL 
FROM dual;