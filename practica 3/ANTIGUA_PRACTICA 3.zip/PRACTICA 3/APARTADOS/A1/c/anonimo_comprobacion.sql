select count(*) from pedidos;
commit;