commit;
set transaction isolation level read committed;

begin
probarmitrans2();
end;