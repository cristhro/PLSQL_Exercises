commit;
set transaction isolation level read committed;

begin
probarmitrans1();
end;