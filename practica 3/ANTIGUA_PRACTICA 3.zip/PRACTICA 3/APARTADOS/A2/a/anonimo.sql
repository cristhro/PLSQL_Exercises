begin
probarmitrans1();
end;

select count(*) from pedidos;