--=============== PROBAR PROPIEDADES ACID =======================
/*
-- ESCENARIO - dos sesiones:
-- usan el aislamiento por defecto: �cual?
*/
-- 2 ----------------------------------------------------------------
Commit;
set autocommit off
-- 4 ----------------------------------------------------------------
-- obtener el id de la transaccion
SELECT dbms_transaction.local_transaction_id
FROM dual;
/* SALIDA:
    null
*/
-- 6 ----------------------------------------------------------------
select * from cliente
where DNI = '00000001';
/* SALIDA:
    00000001	Client A direc 11	911111111111
*/
-- obtener el id de la transaccion
SELECT dbms_transaction.local_transaction_id
FROM dual;
/* SALIDA:
    null
*/
-- 8 ----------------------------------------------------------------
update cliente
set nombrec = 'trans---2'
where DNI = '00000001';
--? Se queda esperando
/* SALIDA:
    00000001	transac-1  direc 11	911111111111
*/
-- 10 ----------------------------------------------------------------
select * from cliente
where DNI = '00000001';
/* SALIDA:
    00000001	transac-1  direc 11	911111111111
*/
-- 12 ----------------------------------------------------------------
  -- confirmamos la transaccion 2
  commit;
  /* SALIDA:
    confirmado.
    1 filas actualizadas.
    confirmado
  */
-- 14 ----------------------------------------------------------------
  select * from cliente
  where DNI = '00000001';
   -- vemos que se ha actualizado
  /* SALIDA:
    00000001	trans---2  direc 11	911111111111
  */
-- 16 ----------------------------------------------------------------
commit
set autocommit on
  /* SALIDA:
     confirmado.
  */
-- CONCLUSION ----------------------------------------------------------------
/*
  Repite las operaciones anteriores: �qu� ha cambiado?
  - Que al modificar en una tabla la transaccion se inicia.
    y Mientras no se haga commit las otras transacciones no podran 
    ver las tablas modificadas.
*/
-- ============== PROBAR NIVELES de AISLAMIENTO =======================
/*
  -- ESCENARIO: dos sesiones serializables:
  -- sesi�n 1 bloquea SOLO una fila con
              select . . TieneT . . . for update
  -- sesion 2 bloquea toda la tabla al hacer
              INSERT INTO Compras
*/
-- 2 ----------------------------------------------------------------
  -- SQL :
  commit;
  set transaction isolation level serializable;
  set autocommit off;
  
  /* SALIDA:
    confirmado.
    transaction ISOLATION correcto.
  */
  -- SQL :
  INSERT INTO Compras VALUES ('00000003',
  '30000002',200, 0501,'sesion2:una',1);
  
  -- SQL :
  select saldo
  from TieneT
  where dni = '00000003' and numt ='30000002';
  /* SALIDA:
    30
  */
   -- SQL :
  INSERT INTO TieneT VALUES ('00000004',
'30000300', 0901, 40300);
-- 4 ----------------------------------------------------------------
   -- SQL :
  select saldo
  from TieneT
  where dni = '00000003' and numt ='30000002';
  -- devuelve el valor inicial : 30
  -- permite consultarla (no deja si es UPDATE)
  
  /* SALIDA:
    30
  */
  -- SQL :
  update TieneT
  set saldo = saldo - 1
  where dni = '00000004' and numt = '30000300';
  /* SALIDA:
    1 filas actualizadas.
  */
  -- permite: esta fila no est� bloqueada
  
  -- SQL :
  select saldo
  from TieneT
  where dni = '00000004' and numt = '30000300';
  -- devuelve el valor actualizado: 40297
  /* SALIDA:
    40297
  */
-- 6 ----------------------------------------------------------------
  -- SQL :
  select *
  from compras
  where dni= '00000003' and numt = '30000002';
  
  /* SALIDA:
    00000003	30000002	1	  501	tienda7             3
    00000003  30000002	200	501	sesion2:una         1
  */
-- 8 ----------------------------------------------------------------
    -- SQL :
    select saldo From  TieneT where dni = '00000005' and numt ='50000030';
   /* SALIDA:
    500
   */
 
  update TieneT
  set saldo = saldo - 1
  where dni = '00000005' and numt ='50000030';
  /* SALIDA:
    Error SQL: ORA-08177: no se puede serializar el acceso para esta transacci�n
    08177. 00000 -  "can't serialize access for this transaction"
    *Cause:    Encountered data changed by an operation that occurred after
               the start of this serializable transaction.
    *Action:   In read/write transactions, retry the intended operation or
               transaction.

  */
  --CAUSA: por se serializable (no por bloqueada)
  
  commit;
  /*
  
  Borrar y crear BDEjemplo
  - da error de tabla Cliente (y otras)
  ORA-00054: recurso ocupado y obtenido con
  NOWAIT especificado o timeout vencido
  ?la otra trans. tiene bloqueada tabla con claves
  ajenas en Cliente
*/

/*
  -- ESCENARIO: dos sesiones serializables:
  -- sesi�n 1 bloquea SOLO una fila con
              select . . TieneT . . . for update
  -- sesion 2 bloquea SOLO otra fila
              select . . TieneT . . . for update
*/

-- 0 ----------------------------------------------------------------
  -- SQL :
  Commit
  -- Transaccion secuenciable
  set transaction isolation level serializable;
  /* SALIDA:
    confirmado.
    transaction ISOLATION correcto.
  */
-- 2 ----------------------------------------------------------------
  -- SQL :
  select saldo
  from TieneT
  where dni = '00000003' and numt ='30000002'
  for update;
  /* SALIDA:
   se queda esperando
  */
   -- SQL :
  select saldo
  from TieneT
  where dni = '00000005' and numt = '50000030'
  for update;
  -- da 500
  -- solo est� bloqueada la otra fila en sesion1
  /* SALIDA:
    500
  */
   -- SQL :
    update TieneT
    set saldo = saldo - 1
    where dni = '00000005' and numt ='50000030';
  /* SALIDA:
    -- queda saldo= 499
    -- deja actualizar porque est� bloqueada otra fila en
    la sesi�n 1
  */
-- 4 ----------------------------------------------------------------
  -- SQL :
  
  /* SALIDA:

  */

-- 6 ----------------------------------------------------------------
  -- SQL :

  /* SALIDA:

  */

-- 8 ----------------------------------------------------------------
  -- SQL :

  /* SALIDA:

  */

-- 10 ----------------------------------------------------------------
  -- SQL :

  /* SALIDA:

  */

-- 12 ----------------------------------------------------------------
  -- SQL :

  /* SALIDA:

  */































