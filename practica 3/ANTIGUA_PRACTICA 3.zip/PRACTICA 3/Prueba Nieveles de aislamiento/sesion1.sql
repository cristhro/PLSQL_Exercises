--=============== PROBAR PROPIEDADES ACID =======================

/*
INSTRUCCIONES
a) Ejecuta antes el script BDejemplo.sql para empezar con la BD limpia
b) Abre el SqlDeveloper una vez (lo llamamos Transacci�n SESION 1)
c) Abre el SqlDeveloper otra vez (lo llamamos Transacci�n SESION2)
d) Ejecuta en el orden indicado cada instrucci�n
e) Estudia el resultado y el cambio en la BD

*/
/*
-- ESCENARIO - dos sesiones:
-- usan el aislamiento por defecto: �cual?
*/

--=============== PROBAR PROPIEDADES ACID =======================
-- 1 ----------------------------------------------------------------
commit ;
set autocommit off;
-- 3 ----------------------------------------------------------------
select * from cliente
where DNI = '00000001';
/* SALIDA:
    00000001	Client A  direc 11	911111111111
*/
SELECT dbms_transaction.local_transaction_id
FROM dual;
-- obtener el id de la transaccion
/* SALIDA:
   null
*/
-- 5 ----------------------------------------------------------------
-- modificamos el cliente con dni 00000001
update cliente
set nombrec = 'transac-1'
where DNI = '00000001';
/* SALIDA:
    confirmado.
    1 filas actualizadas.null
*/
-- obtener el id de la transaccion
SELECT dbms_transaction.local_transaction_id
FROM dual;
/* SALIDA:
   2.26.21890
*/
-- 7 ----------------------------------------------------------------
select * from cliente
where DNI = '00000001';
/* SALIDA:
    00000001	transac-1  direc 11	911111111111
*/
-- 9 ----------------------------------------------------------------
  --HACEMOS Commit y se desbloquea la fila 
  commit;
/* SALIDA:
    confirmado.
    1 filas actualizadas.
    confirmado.
*/
-- 11 ----------------------------------------------------------------
  select * from cliente
  where DNI = '00000001';
  -- vemos que no esta actualizada respecto la sesion 2
/* SALIDA:
   00000001	transac-1 direc 11	911111111111
*/  
  SELECT dbms_transaction.local_transaction_id
  FROM dual;
  -- devuelve null porque no hay transaccion activa
/* SALIDA:
    null 
*/
-- 13 ----------------------------------------------------------------
 select * from cliente
 where DNI = '00000001';
  -- vemos que se ha actualizado
  /* SALIDA:
    00000001	trans---2	direc 11	911111111111
  */
-- 15 ----------------------------------------------------------------
commit
set autocommit on
  /* SALIDA:
   confirmado.
  */
-- CONCLUSION ----------------------------------------------------------------
/*
  Repite las operaciones anteriores: �qu� ha cambiado?
  - Que al modificar en una tabla la transaccion se inicia.
    y Mientras no se haga commit las otras transacciones no podran 
    ver las tablas modificadas.
*/

-- ============== PROBAR NIVELES de AISLAMIENTO =======================
/*
  -- ESCENARIO: dos sesiones serializables:
  -- sesi�n 1 bloquea SOLO una fila con
              select . . TieneT . . . for update
  -- sesion 2 bloquea toda la tabla al hacer
              INSERT INTO Compras
*/
-- 1 ----------------------------------------------------------------
  -- SQL :
  set transaction isolation level serializable;
  /* SALIDA:
     transaction ISOLATION correcto.
  */
  -- SQL :
  set autocommit off;
-- 3 ----------------------------------------------------------------
   -- solo bloquea esa fila para actualizar
  select saldo
  from TieneT
  where dni = '00000003' and numt ='30000002'
  for update;
 
  /* SALIDA:
    30
  */
-- 5 ----------------------------------------------------------------
  -- SQL :
  update TieneT
  set saldo = saldo - 1
  where dni = '00000003' and numt ='30000002';
  
  -- permite: la bloque� esta sesi�n
  /* SALIDA:
    1 filas actualizadas.
  */
   -- SQL :
  select saldo
  from TieneT
  where dni = '00000003' and numt ='30000002';
  -- devuelva el valor actualizado por ella: 29
  /* SALIDA:
    29
  */
-- 7 ----------------------------------------------------------------
  -- SQL :
  INSERT INTO Compras VALUES ('00000003',
'30000002',111, 0501,'sesion1:??',1);
  /* SALIDA:
    1 filas insertadas.
  */
  -- SQL :
  select *
  from compras
  where dni= '00000003' and numt = '30000002';
  /* SALIDA:
    00000003	30000002	1	501	tienda7             	3
    00000003	30000002	111	501	sesion1:??          	1
    00000003	30000002	200	501	sesion2:una         	1
  */
-- 9 ----------------------------------------------------------------
  -- SQL :
  commit;
  /* SALIDA:
    confirmado
  */
/*  
  -- ESCENARIO: dos sesiones serializables:
  -- sesi�n 1 bloquea SOLO una fila con
              select . . TieneT . . . for update
  -- sesion 2 bloquea SOLO otra fila
              select . . TieneT . . . for update
*/
-- 0 ----------------------------------------------------------------
  -- SQL :
  commit;
  -- Transaccion secuenciable
  set transaction isolation level serializable;
  
  /* SALIDA:
    transaction ISOLATION correcto.
  */
-- 1 ----------------------------------------------------------------
  -- SQL :
  -- modificamos una fila de la tabla Tienet
  select saldo
  from TieneT
  where dni = '00000003' and numt ='30000002'
  for update;
  -- solo bloquea esa fila = 30
  /* SALIDA:
    30
  */

-- 3 ----------------------------------------------------------------
  -- SQL :
  update TieneT
  set saldo = saldo - 1
  where dni = '00000003' and numt ='30000002';
  
  /* SALIDA:
    29
  */
  -- SQL :
  -- esta fila esta siendo modificada por la sesion 2
  update TieneT
  set saldo = saldo - 1
  where dni = '00000005' and numt ='50000030';
  /* SALIDA:
    se queda esperando
  */
  -- por ser serializable no permite actualizar,
  --Aunque ha liberado la fila la sesion2
  -- no aborta la trans
  -- SQL :
  select saldo
  from TieneT
  where dni = '00000005' and numt = '50000030';
  /* SALIDA:
    499
  */
  commit;
  
/*
  -- ESCENARIO: dos sesiones read committed:
  -- sesi�n 1 bloquea SOLO una fila con
              select . . TieneT . . . for update
  -- sesion 2 bloquea SOLO otra fila
              select . . TieneT . . . for update
*/  

commit;
set transaction isolation level read committed;
-- 1 ----------------------------------------------------------------
  -- SQL :
  -- abre una transaccion con el for update
  select saldo
  from TieneT
  where dni = '00000003' and numt ='30000002'
  for update;
  -- solo bloquea esa fila
  /* SALIDA:
    30
  */

-- 3 ----------------------------------------------------------------
  -- SQL :
  select saldo
  from TieneT
  where dni = '00000005' and numt = '50000030';
  /* SALIDA:
    500
  */

-- 5 ----------------------------------------------------------------
  -- SQL :
  select saldo
  from TieneT
  where dni = '00000005' and numt = '50000030';
 
   -- despues de que  la sesion 2 hizo commit.
   -- se actualiza estando aun en su transaccion.
   -- por ser read commited
  /* SALIDA:
    499
  */

/*
-- ESCENARIO: dos sesiones read committed:
    -- sesi�n 1 bloquea tabla exclusive
                Lock table Tienet in exclusive mode
                select . . TieneT . . . for update
    -- sesion 2 bloquea SOLO otra fila
                select . . TieneT . . . for update

*/
set transaction isolation level read committed;
-- 1 ----------------------------------------------------------------
  -- SQL :
  Lock table Tienet in exclusive mode;
  /* SALIDA:
    Lock correcto.
  */

-- 3 ----------------------------------------------------------------
  -- SQL :
  update TieneT
  set saldo = saldo - 1
  where dni = '00000003' and numt ='30000002';
  /* SALIDA:
    1 filas actualizadas.
  */
    -- SQL :
  Commit;
  /* SALIDA:
  confirmado
  */
  -- termina transacci�n
  -- empieza otra
-- 5 ----------------------------------------------------------------
  -- SQL :
  Lock table Tienet in share mode   
  /* SALIDA:
    Se queda esperando (cancelo a mano)
    porque sesion2 hizo un update que bloque la tabla
  */
  -- 6 ----------------------------------------------------------------
  -- SQL :
  Lock table Tienet in share mode;
  -- ejecuta el lock
  Lock table Tienet in exclusive mode;
  -- se queda esperando
  commit;
  


